import tkinter as tk
from gui import CNCLatheControllerApp

if __name__ == "__main__":
    root = tk.Tk()
    app = CNCLatheControllerApp(root)
    root.mainloop()
