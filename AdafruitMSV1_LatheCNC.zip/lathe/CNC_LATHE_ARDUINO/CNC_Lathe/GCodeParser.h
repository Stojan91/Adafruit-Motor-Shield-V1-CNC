#ifndef GCODE_PARSER_H
#define GCODE_PARSER_H

#include <Arduino.h>

void processGCode(String command);

#endif
